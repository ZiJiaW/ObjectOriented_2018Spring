package elev;

public interface ElevAction {
	public void up(int n);
	public void down(int n);
	public void open();
}
